#!/bin/bash
g++ main.cpp; ./a.out $1